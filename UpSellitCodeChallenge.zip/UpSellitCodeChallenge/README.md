# UpSellit Code Challenge

Launch index.html in a browser and follow the instructions. Good luck!

### Future Challenges
- Slow-loading DOM
- setTimeout() vs. setInterval()
- Debugging
    - null/undefined checks
    - TT execution doesn't match the mockup
- AJAX GET/POST
